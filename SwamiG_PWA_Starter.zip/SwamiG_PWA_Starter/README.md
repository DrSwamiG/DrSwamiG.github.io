# SwamiG PWA Starter

This adds Progressive Web App (PWA) features (installable + basic offline) to your existing site.

## Files
- `manifest.webmanifest` — app metadata and icons
- `sw.js` — service worker for caching/offline
- `app.js` — registers the service worker
- `offline.html` — friendly offline page
- `icons/icon-192.png`, `icons/icon-512.png` — placeholders (replace with your logo variants)

## How to integrate (GitHub Pages or any static host)
1. Copy **all** files to your site's web root (where `index.html` lives). Keep the same paths:
   - `/manifest.webmanifest`
   - `/sw.js`
   - `/app.js`
   - `/offline.html`
   - `/icons/...`
2. In your main HTML `<head>`, add:
   ```html
   <link rel="manifest" href="/manifest.webmanifest">
   <meta name="theme-color" content="#0b0b0f">
   <meta name="apple-mobile-web-app-capable" content="yes">
   <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
   <link rel="apple-touch-icon" href="/icons/icon-192.png">
   <script defer src="/app.js"></script>
   ```
3. Make sure the site is served over **HTTPS** (GitHub Pages and Cloudflare do this).
4. Commit & deploy. Visit your site, then check **Chrome → Lighthouse → PWA** to verify installability.

## Customization
- Update names/colors in `manifest.webmanifest`.
- Replace the two placeholder icons in `/icons` with your brand images (keep sizes 192×192 and 512×512).
- Add more URLs to `PRECACHE_URLS` in `sw.js` for guaranteed offline pages (e.g., `/iyafalanlu.html`).

## Notes
- Service workers require the files to be at or above the scope they control. Keeping `sw.js` at `/` is simplest.
- If your site uses subpaths (e.g., `/Lineage/`), this starter still works since scope is `/`.
